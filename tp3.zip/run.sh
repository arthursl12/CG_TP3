#!/bin/bash
# Formato: pypy3 main.py [entrada] [saída]
pypy3 main.py CG_examples/test5.in out1.ppm

# Formato: pypy3 main.py [entrada] [saída] [-t [largura] [altura]] [-a samplesAA]
# pypy3 main.py examples/gif1.in examples/gif1.gif -t 1280 720