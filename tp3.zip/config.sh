#!/bin/bash
pypy3 -m pip install -r requirements.txt
imageio_download_bin freeimage