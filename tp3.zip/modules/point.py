from modules.vector import Vector

class Point(Vector):
    """Armazenado como um vetor 3D"""
    pass